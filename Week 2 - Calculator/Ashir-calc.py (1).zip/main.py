# Python3 Program to calculate the 
# Surface area of a triangular prism 
  
# Function for calculating the area 
def Calculate_area(): 
      
    # Initialization 
    b = 8
    h = 14
    s1 = 7
    s2 = 6
    s3 = 6
    Ht = 8
  
    # Formula for calculating the area 
    SA = b * h + (s1 + s2 + s3) * Ht 
  
    # Displaying the area 
    print ("The area of triangular prism is :",SA) 
  
# Driver code 
if __name__ == '__main__': 
    # Function calling 
    Calculate_area() 
  
# This code is contributed by  
#Ashir Ahmed 