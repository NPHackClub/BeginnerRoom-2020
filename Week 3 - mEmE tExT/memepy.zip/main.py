y = "Esha"
print((y[0:1]).upper() + (y[1]) + (y[2]).upper() + (y[3]) + (y[0]) +
      (y[1]).upper() + (y[2]) + (y[3]).upper())